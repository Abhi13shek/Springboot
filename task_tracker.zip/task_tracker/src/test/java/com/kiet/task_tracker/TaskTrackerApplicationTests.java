package com.kiet.task_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
