package com.kiet.Abhishek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbhishekApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbhishekApplication.class, args);
	}

}
