package com.kiet.Abhishek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbhishekApplicationTests {

	@Test
	void contextLoads() {
	}

}
